import { useState } from 'react'
import { motion } from 'framer-motion'
import { Helmet } from 'react-helmet-async'
import ProjectCard from '../components/ProjectCard'
import ProjectModal from '../components/ProjectModal'

const Audiovisual = () => {
  const [selectedProject, setSelectedProject] = useState<any>(null)
  const [selectedCategory, setSelectedCategory] = useState('todos')
  
  const documentalesData = [
    {
      id: 'cuenca-rios-piedra',
      title: 'La cuenca de los ríos de piedra',
      subtitle: 'Memoria del agua en Ciudad de México',
      year: '2019',
      duration: '75 min',
      type: 'Largometraje documental',
      director: 'Pablo Benjamín Nieto Mercado',
      description: 'Un viaje por la transformación urbana de la Ciudad de México a través de cuatro testimonios de quienes vivieron la desaparición del agua: ríos entubados, lagos desecados y canales que se convirtieron en calles. La película explora cómo la infraestructura urbana transformó el paisaje hídrico de la capital mexicana.',
      image: '/images/experimental_video_art_installation_dark_gallery.jpg',
      videoUrl: 'https://vimeo.com/43123787',
      websiteUrl: 'http://melvinrecords.com.mx/cuenca/',
      featured: true,
      awards: [
        'Primer lugar Video Documental FINI 2022',
        'Social Impact Award Estados Unidos 2022',
        'Apoyo Música México 2022',
        'Mención Honorífica Festival Miradas Locales 2020',
        'Estímulo FONCA Coinversiones Culturales 2018',
        'Estímulo IMCINE Creadores Cinematográficos 2017'
      ],
      festivals: [
        'DocsMX 2024', 'FINI - UAEH México', 'Cinema Planeta',
        'Festival Latinoamericano Quito', 'FICAA México',
        'Korea International Ethnographic Film Festival',
        'Cinema Urbana Brasil', 'Humano Film Festival Tijuana'
      ],
      presentations: [
        '2024/09/05: Cineclub Micelio, Casa Gallina',
        '2023/12/28: Korea International Ethnographic Film Festival',
        '2023/06/05: IMCINE "3ra Muestra de Cine en Defensa del Territorio y el Agua"',
        '2022/09/07: TourCinemaPlaneta2022',
        '2022/08/17: Cinema Urbana - 4ª Mostra Internacional',
        '2022/04/21: Festival Internacional de la Imagen FINI',
        '2021/12/01: VI Festival de Cine Etnográfico de Ecuador'
      ]
    },
    {
      id: 'atl-inundar',
      title: 'ATL / Inundar la Ciudad',
      subtitle: 'WebDoc e instalación transmedia',
      year: '2020-2023',
      duration: '45 min + instalación',
      type: 'WebDoc / Instalación',
      director: 'Pablo Nieto Mercado',
      description: 'Profundizamos en la cadena laboral de las compras en línea en el Valle de México, abordando la precariedad laboral, la dependencia tecnológica y la gentrificación. Esta historia sigue a varios personajes cuyas vidas están conectadas por la cadena de trabajo necesaria para que las compras en línea lleguen a su destino.',
      image: '/images/video_art_installation_projections_dark_gallery.jpg',
      videoUrl: 'https://vimeo.com/797403406',
      featured: false,
      awards: [
        'GANADOR DocuWeb - Encuentro de Imagen MMXX 2020',
        'Doc Society UK/USA',
        'Top Ten Artist Alemania 2021'
      ],
      festivals: [
        'Simultan Festival Rumania', 'AIU Film Festival Kuwait',
        'Steve Aronson International Film Festival USA',
        'PlataformaMX Puebla DocsMX', 'Centro de la Imagen México'
      ],
      presentations: [
        '2024/10/03: Simultan Festival - Object of Desire, Timisoara Rumania',
        '2023/06/19: Inundar la Ciudad @ PlataformaMX Puebla DocsMX',
        '2021/06/01: Concebir, nombrar, decir SPF 2019 - Centro de la imagen',
        '2020/08/20: GANADOR DocuWeb @ Encuentro de Imagen MMXX'
      ]
    },
    {
      id: 'invasion',
      title: 'Invasión',
      subtitle: 'Corto experimental',
      year: '2021',
      duration: '12 min',
      type: 'Cortometraje experimental',
      director: 'Melvin Records',
      description: 'Una exploración visual experimental que reflexiona sobre la invasión tecnológica en los espacios urbanos contemporáneos. La pieza combina elementos de videoarte con narrativa experimental.',
      image: '/images/melvin_records_invasion_2.jpg',
      videoUrl: 'https://youtu.be/eDlqRi6FVmM',
      featured: false,
      awards: [
        '2do Lugar Técnicas Alternativas FINI 2025',
        'Finalista FINI 2025',
        'Festival Internacional de la Imagen FINI',
        '24FRAME Future Film Fest Bologna'
      ],
      festivals: [
        'Expanded Cinema Helsinki', 'Festival de Cine Radical Bolivia',
        'International Video Art Forum Arabia Saudita',
        'Kino Club Helsinki', 'Bent and Broken USA'
      ],
      presentations: [
        '2025/04/18: 2do Lugar Técnicas Alternativas @ FINI - UAEH',
        '2025/02/14: Finalista FINI 2025',
        '2024/01/30: Festival de Cine Radical 2024',
        '2023/12/09: Kino Club Helsinki- Expanded Cinema vol.2',
        '2022/07/19: International Video Art Forum'
      ]
    },
    {
      id: 'cibertrip',
      title: 'CiberTrip',
      subtitle: 'Exploración digital contemporánea',
      year: '2022',
      duration: '30 min',
      type: 'Corto documental',
      director: 'Pablo Nieto Mercado',
      description: 'Una exploración audiovisual de la experiencia digital contemporánea, navegando entre realidades virtuales y físicas en el México del siglo XXI. El proyecto documenta cómo la tecnología digital ha transformado nuestra percepción del espacio y el tiempo.',
      image: '/images/video_art_installation_screens_dark_gallery.jpg',
      videoUrl: 'https://youtu.be/EVDnSaMiuwM',
      featured: false,
      awards: [
        'Festival Internacional de Cine de la No-Violencia Activa'
      ],
      festivals: [
        'FICNOVA', 'FECIBA México', 'Ruta Maya Film Festival',
        'RetoDocsMX 2020'
      ]
    },
    {
      id: 'cuerpos-agua',
      title: 'Cuerpos de agua',
      subtitle: 'Reflexión visual microscópica',
      year: '2023',
      duration: '12 min',
      type: 'Cortometraje experimental',
      director: 'Pablo Benjamín Nieto Mercado',
      description: 'Una reflexión visual sobre la transformación de la vida y la energía a través de los órganos, usando el agua como vehículo narrativo del ciclo microscópico de la vida. La pieza explora la conexión entre los cuerpos humanos y los ciclos naturales del agua.',
      image: '/images/immersive_van_gogh_starry_night_art_projection_installation.jpg',
      videoUrl: 'https://vimeo.com/785731129',
      websiteUrl: 'http://melvinrecords.com.mx/cuerpos/',
      featured: false
    },
    {
      id: 'cuerno-chivo',
      title: 'Cuerno de Chivo',
      subtitle: 'Documental de grindcore underground',
      year: '2023',
      duration: '45 min',
      type: 'Documental musical',
      director: 'Pablo Nieto Mercado',
      description: '"Cuerno de Chivo" es una banda de grindcore de Tultitlán, Estado de México, que lleva 10 años sacudiendo escenarios con su implacable crítica al sistema. Este documental invita a los espectadores al mundo crudo y underground de la banda, siguiendo su viaje hacia el lanzamiento de su álbum debut.',
      image: '/images/vintage_experimental_music_studio_industrial.jpg',
      videoUrl: 'https://youtu.be/YGzOnoQPPwo',
      featured: false
    }
  ]
  
  const videocasts = [
    {
      id: 'estilo-vida-graff',
      title: 'Estilo de Vida Graff',
      subtitle: 'Videocast de arte urbano',
      year: '2024',
      duration: 'Serie de episodios',
      type: 'Videocast',
      director: 'Sid Bidek & Pablo Nieto',
      description: '"Estilo de Vida Graff" es un videocast colaborativo que nace de Hacklab La Resistencia, explorando la cultura del graffiti y mostrando el talento emergente del Estado de México. Presentado por Sid Bidek, ofrece una mirada íntima a las vidas y obras de los artistas urbanos.',
      image: '/images/overlapping_vinyl_records_dark_background.jpg',
      videoUrl: 'https://youtu.be/k64wf2pGVvo',
      featured: false
    },
    {
      id: 'visionarios-creativos',
      title: 'Visionarios Creativos Live',
      subtitle: 'EP colaborativo Hacklab',
      year: '2024',
      duration: '6 episodios',
      type: 'Videocast musical',
      director: 'Pablo Nieto & Sid Bidek',
      description: 'Serie de entrevistas con creadores y artistas contemporáneos del ámbito digital y experimental. Junto a Sid Bidek, estamos grabando este EP que presenta una introducción creada utilizando inteligencia artificial para explorar nuevas fronteras sonoras.',
      image: '/images/minimal-modern-technology-lab-workspace-setup.jpg',
      videoUrl: 'https://youtu.be/no4BWZCyZtw',
      featured: false
    }
  ]
  
  const promocionales = [
    {
      id: 'promocionales-hacklab',
      title: 'Vídeos Promocionales Hacklab',
      subtitle: 'Cortometrajes de IA',
      year: '2024',
      duration: 'Serie de videos cortos',
      type: 'Videos promocionales',
      director: 'Pablo Nieto Mercado',
      description: 'Esta serie de vídeos promocionales de Hacklab La Resistencia está creada utilizando diversas herramientas de inteligencia artificial. Los videos destacan la venta de pulque y otros eventos, basándose en referencias culturales de películas icónicas como Star Wars, Westerns, Jurassic Park.',
      image: '/images/electronics_hacklab_workbench_tools.jpg',
      videoUrl: 'https://youtu.be/m4wzu_n6hY4',
      featured: false,
      technologies: ['Inteligencia Artificial', 'Machine Learning', 'Video Generativo']
    }
  ]
  
  const categories = [
    { id: 'todos', label: 'Todos los Proyectos' },
    { id: 'documentales', label: 'Documentales' },
    { id: 'videocasts', label: 'Videocasts' },
    { id: 'promocionales', label: 'Videos Promocionales' }
  ]
  
  const getFilteredProjects = () => {
    switch (selectedCategory) {
      case 'documentales':
        return documentalesData
      case 'videocasts':
        return videocasts
      case 'promocionales':
        return promocionales
      default:
        return [...documentalesData, ...videocasts, ...promocionales]
    }
  }
  
  const featuredProject = documentalesData.find(doc => doc.featured) || documentalesData[0]
  const allProjects = getFilteredProjects()

  return (
    <>
      <Helmet>
        <title>Catálogo Audiovisual | Documentales y Proyectos Experimentales | Melvin Records</title>
        <meta name="description" content="Catálogo completo de producción audiovisual Melvin Records: documentales premiados como 'La cuenca de los ríos de piedra', cortometrajes experimentales, videocasts y series como Hacklab La Resistencia." />
        <meta name="keywords" content="documentales CDMX, video experimental México, Pablo Nieto Mercado, Melvin Records audiovisual, cortometrajes independientes, videocasts alternativos, Hacklab La Resistencia" />
        <link rel="canonical" href="https://melvinrecords.com/audiovisual" />
        
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "CreativeWorkSeries",
            "name": "Catálogo Audiovisual Melvin Records",
            "description": "Documentales de memoria urbana, cortometrajes experimentales, videocasts y series documentales",
            "creator": {
              "@type": "Organization",
              "name": "Melvin Records"
            },
            "about": ["Documentales", "Video Experimental", "Memoria Urbana", "Ciudad de México", "Arte Digital"],
            "numberOfEpisodes": allProjects.length
          })}
        </script>
      </Helmet>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="section-container">
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="mb-8">
                <span className="block text-melvin-text-primary">CATÁLOGO</span>
                <span className="block text-gradient-cyan">AUDIOVISUAL</span>
              </h1>
              <p className="text-xl text-melvin-text-secondary max-w-4xl mx-auto leading-relaxed">
                Producción audiovisual completa de Melvin Records: documentales premiados, 
                experimentación visual, videocasts alternativos y series documentales que 
                exploran la memoria urbana, tecnología y cultura contemporánea.
              </p>
            </motion.div>
          </div>

          {/* Category Filter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-wrap justify-center gap-4 mb-16"
          >
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-full transition-all duration-300 ${
                  selectedCategory === category.id
                    ? 'bg-melvin-accent-cyan text-melvin-bg-primary font-semibold'
                    : 'bg-melvin-bg-secondary text-melvin-text-secondary hover:bg-melvin-text-secondary/10 hover:text-melvin-accent-cyan'
                }`}
              >
                {category.label}
              </button>
            ))}
          </motion.div>

          {/* Featured Project */}
          {selectedCategory === 'todos' && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="mb-20"
            >
              <ProjectCard
                project={featuredProject}
                onClick={() => setSelectedProject(featuredProject)}
                variant="featured"
              />
            </motion.div>
          )}
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-20 border-t border-melvin-text-secondary/20">
        <div className="section-container">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="mb-6 text-melvin-text-primary">
              <span className="text-gradient-cyan">
                {selectedCategory === 'todos' ? 'Todos los' : categories.find(c => c.id === selectedCategory)?.label}
              </span> Proyectos
            </h2>
            <p className="text-xl text-melvin-text-secondary max-w-3xl mx-auto">
              {selectedCategory === 'documentales' && 'Exploraciones documentales de la memoria urbana y transformación social en México.'}
              {selectedCategory === 'videocasts' && 'Series de videocasts que documentan procesos creativos y culturales contemporáneos.'}
              {selectedCategory === 'promocionales' && 'Videos promocionales creados con tecnologías de inteligencia artificial.'}
              {selectedCategory === 'todos' && 'Catálogo completo de producciones audiovisuales ordenadas cronológicamente.'}
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {allProjects
              .filter(project => selectedCategory === 'todos' ? !project.featured : true)
              .sort((a, b) => parseInt(b.year) - parseInt(a.year))
              .map((project, index) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onClick={() => setSelectedProject(project)}
                  variant="default"
                />
              ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 border-t border-melvin-text-secondary/20">
        <div className="section-container">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h3 className="text-2xl font-manrope font-bold text-melvin-text-primary mb-12">
              Impacto y Reconocimiento
            </h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-melvin-accent-cyan mb-2">
                  {allProjects.length}+
                </div>
                <div className="text-melvin-text-secondary">Proyectos</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-melvin-accent-cyan mb-2">
                  15+
                </div>
                <div className="text-melvin-text-secondary">Premios</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-melvin-accent-cyan mb-2">
                  15+
                </div>
                <div className="text-melvin-text-secondary">Años</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-melvin-accent-cyan mb-2">
                  50+
                </div>
                <div className="text-melvin-text-secondary">Festivales</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Project Modal */}
      <ProjectModal
        isOpen={!!selectedProject}
        onClose={() => setSelectedProject(null)}
        project={selectedProject || {}}
      />
    </>
  )
}

export default Audiovisual