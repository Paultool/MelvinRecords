import { motion } from 'framer-motion'
import { Helmet } from 'react-helmet-async'
import { Link } from 'react-router-dom'
import { ExternalLink, Play, Calendar, User } from 'lucide-react'
import { useState } from 'react'

const Musica = () => {
  const [selectedCategory, setSelectedCategory] = useState('todos')

  const releases = [
    // Lechones Sangrientos (14 releases)
    { id: 1, title: 'Oculum Lentum Nobile', artist: 'Lechones Sangrientos', year: '2024', genre: 'Experimental', category: 'lechones', bandcampId: 'album-id-1' },
    { id: 2, title: 'Vitrinas-sanirtiV', artist: 'Lechones Sangrientos', year: '2024', genre: 'Noise', category: 'lechones', bandcampId: 'album-id-2' },
    { id: 3, title: 'Canciones para perros que viajan en metro', artist: 'Lechones Sangrientos', year: '2023', genre: 'Experimental', category: 'lechones', bandcampId: 'album-id-3' },
    { id: 4, title: 'La Quema', artist: 'Lechones Sangrientos', year: '2023', genre: 'Ambient', category: 'lechones', bandcampId: 'album-id-4' },
    { id: 5, title: 'Crónicas de un hombre barbado', artist: 'Lechones Sangrientos', year: '2023', genre: 'Electronic', category: 'lechones', bandcampId: 'album-id-5' },
    { id: 6, title: 'Live in Café V lese Prague', artist: 'Lechones Sangrientos', year: '2022', genre: 'Live Recording', category: 'lechones', bandcampId: 'album-id-6' },
    { id: 7, title: 'Soundex', artist: 'Lechones Sangrientos', year: '2022', genre: 'Sound Art', category: 'lechones', bandcampId: 'album-id-7' },
    { id: 8, title: 'Te quiero Mucho', artist: 'Lechones Sangrientos', year: '2022', genre: 'Experimental', category: 'lechones', bandcampId: 'album-id-8' },
    { id: 9, title: 'Piporama Live in Puebla', artist: 'Lechones Sangrientos', year: '2021', genre: 'Live Recording', category: 'lechones', bandcampId: 'album-id-9' },
    { id: 10, title: 'Jamon Sesion II', artist: 'Lechones Sangrientos', year: '2021', genre: 'Session', category: 'lechones', bandcampId: 'album-id-10' },
    { id: 11, title: 'Kaseum', artist: 'Lechones Sangrientos', year: '2021', genre: 'Electronic', category: 'lechones', bandcampId: 'album-id-11' },
    { id: 12, title: 'Jamon Session', artist: 'Lechones Sangrientos', year: '2020', genre: 'Session', category: 'lechones', bandcampId: 'album-id-12' },
    // Colaboraciones Lechones
    { id: 13, title: 'Diploma', artist: 'Lechones Sangrientos & Vulgar Disease', year: '2022', genre: 'Collaboration', category: 'colaboraciones', bandcampId: 'album-id-13' },
    { id: 14, title: 'Vida Yonqui', artist: 'Lechones Sangrientos & Vulgar Disease', year: '2021', genre: 'Collaboration', category: 'colaboraciones', bandcampId: 'album-id-14' },
    // Otros artistas
    { id: 15, title: 'Visionarios Creativos Vol. 1', artist: 'Visionarios Creativos', year: '2024', genre: 'Experimental', category: 'otros', bandcampId: 'album-id-15' },
    { id: 16, title: 'Visionarios Creativos Vol. 2', artist: 'Visionarios Creativos', year: '2024', genre: 'Electronic', category: 'otros', bandcampId: 'album-id-16' },
    { id: 17, title: 'Live Hacklab La Resistencia', artist: 'Visionarios Creativos', year: '2023', genre: 'Live Recording', category: 'otros', bandcampId: 'album-id-17' },
    { id: 18, title: 'Tonathiu Sessions', artist: 'Tonathiu De La Cruz Barajas', year: '2023', genre: 'Ambient', category: 'otros', bandcampId: 'album-id-18' },
    { id: 19, title: 'Underground Rhymes', artist: 'The Foursome Rap', year: '2023', genre: 'Hip-Hop', category: 'otros', bandcampId: 'album-id-19' },
    { id: 20, title: 'RuidoRimaRomance EP', artist: 'RuidoRimaRomance', year: '2022', genre: 'Experimental Hip-Hop', category: 'otros', bandcampId: 'album-id-20' },
    { id: 21, title: 'Aleluya Digital', artist: 'El Conjunto Aleluya', year: '2022', genre: 'Digital Folk', category: 'otros', bandcampId: 'album-id-21' },
    { id: 22, title: 'Telmex Sessions', artist: 'Telmex', year: '2021', genre: 'Electronic', category: 'otros', bandcampId: 'album-id-22' },
    { id: 23, title: 'Mosca Electronic', artist: 'Peter Mosca', year: '2021', genre: 'Electronic', category: 'otros', bandcampId: 'album-id-23' },
    { id: 24, title: 'Lle Experimental', artist: 'Lle', year: '2021', genre: 'Experimental', category: 'otros', bandcampId: 'album-id-24' },
    { id: 25, title: 'Reptilian Love Songs', artist: 'Love Reptilian People', year: '2020', genre: 'Psychedelic', category: 'otros', bandcampId: 'album-id-25' },
    { id: 26, title: 'Psíquicos 24 Horas', artist: 'Psíquicos 24 Horas', year: '2020', genre: 'Experimental', category: 'otros', bandcampId: 'album-id-26' }
  ]

  const categories = [
    { key: 'todos', label: 'Todos los Releases', count: 26 },
    { key: 'lechones', label: 'Lechones Sangrientos', count: 12 },
    { key: 'colaboraciones', label: 'Colaboraciones', count: 2 },
    { key: 'otros', label: 'Otros Artistas', count: 12 }
  ]

  const filteredReleases = selectedCategory === 'todos' 
    ? releases 
    : releases.filter(release => release.category === selectedCategory)

  return (
    <>
      <Helmet>
        <title>Catálogo Musical | Melvin Records - Música Experimental y Underground México</title>
        <meta name="description" content="Explora 26 releases de música experimental mexicana. Lechones Sangrientos, Visionarios Creativos y más. Laboratorio musical independiente desde Tultitlán, México." />
        <meta name="keywords" content="música experimental México, underground mexicano, Lechones Sangrientos, Melvin Records, música independiente, Tultitlán" />
        <link rel="canonical" href="https://melvinrecords.com/musica" />
        
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "MusicPlaylist",
            "name": "Catálogo Musical Melvin Records",
            "description": "Colección completa de 26 releases de música experimental y underground",
            "publisher": {
              "@type": "MusicGroup",
              "name": "Melvin Records"
            },
            "numTracks": 26,
            "genre": ["Experimental", "Electronic", "Ambient", "Noise", "Underground"]
          })}
        </script>
      </Helmet>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="section-container">
          <div className="asymmetric-grid">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="mb-8">
                <span className="block text-melvin-text-primary">CATÁLOGO</span>
                <span className="block text-gradient-cyan">MUSICAL</span>
              </h1>
              <p className="text-xl text-melvin-text-secondary mb-8 leading-relaxed">
                26 releases de música experimental, ambient, noise y underground mexicana. 
                Una exploración sonora que conecta laboratorio, calle y memoria urbana.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a 
                  href="https://melvinrecords.bandcamp.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary group"
                >
                  <Play className="mr-2 group-hover:scale-110 transition-transform" size={20} />
                  Escuchar en Bandcamp
                  <ExternalLink className="ml-2" size={16} />
                </a>
                <Link to="/musica/artistas/lechones-sangrientos" className="btn-secondary">
                  Ver Artista Principal
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <img
                src="/images/overlapping_vinyl_records_dark_background.jpg"
                alt="Catálogo musical Melvin Records"
                className="w-full h-96 lg:h-[500px] object-cover card"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-melvin-bg-primary/50 to-transparent card" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-12 border-y border-melvin-text-secondary/20">
        <div className="section-container">
          <div className="flex flex-wrap gap-4 justify-center">
            {categories.map((category) => (
              <button
                key={category.key}
                onClick={() => setSelectedCategory(category.key)}
                className={`px-6 py-3 font-manrope font-medium uppercase tracking-wider text-sm border transition-all duration-300 ${
                  selectedCategory === category.key
                    ? 'bg-melvin-accent-cyan text-melvin-bg-primary border-melvin-accent-cyan'
                    : 'text-melvin-text-secondary border-melvin-text-secondary hover:border-melvin-accent-cyan hover:text-melvin-accent-cyan'
                }`}
              >
                {category.label} ({category.count})
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Releases Grid */}
      <section className="py-20">
        <div className="section-container">
          <motion.div 
            layout
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          >
            {filteredReleases.map((release, index) => (
              <motion.div
                key={release.id}
                layout
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -30 }}
                transition={{ duration: 0.6, delay: index * 0.05 }}
                className="card-interactive group"
              >
                <div className="aspect-square bg-melvin-bg-secondary mb-4 relative overflow-hidden">
                  <img
                    src="/images/overlapping_vinyl_records_dark_background.jpg"
                    alt={`${release.title} - ${release.artist}`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-melvin-bg-primary/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Play className="text-melvin-accent-cyan" size={48} />
                  </div>
                  <div className="absolute top-3 right-3">
                    <span className="text-xs font-manrope font-medium uppercase tracking-wider text-melvin-accent-cyan bg-melvin-bg-primary/80 px-2 py-1">
                      {release.genre}
                    </span>
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="text-lg font-manrope font-semibold text-melvin-text-primary mb-2 group-hover:text-melvin-accent-cyan transition-colors duration-300">
                    {release.title}
                  </h3>
                  
                  <div className="flex items-center text-melvin-text-secondary mb-2">
                    <User size={14} className="mr-2" />
                    <span className="text-sm">{release.artist}</span>
                  </div>
                  
                  <div className="flex items-center text-melvin-text-secondary mb-4">
                    <Calendar size={14} className="mr-2" />
                    <span className="text-sm">{release.year}</span>
                  </div>

                  <div className="flex gap-2">
                    <a
                      href={`https://melvinrecords.bandcamp.com/album/${release.bandcampId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 bg-melvin-accent-cyan text-melvin-bg-primary text-center py-2 text-sm font-manrope font-medium uppercase tracking-wider hover:bg-melvin-accent-magenta transition-colors duration-300"
                    >
                      Escuchar
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Bandcamp Integration */}
      <section className="py-20 bg-melvin-bg-secondary">
        <div className="section-container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="mb-6 text-melvin-text-primary">
              Escucha el <span className="text-gradient-cyan">Catálogo Completo</span>
            </h2>
            <p className="text-xl text-melvin-text-secondary mb-12 max-w-3xl mx-auto">
              Todo nuestro catálogo está disponible en Bandcamp. Apoya directamente 
              a los artistas y disfruta de música experimental mexicana sin límites.
            </p>

            {/* Embedded Bandcamp Player */}
            <div className="max-w-4xl mx-auto mb-8">
              <iframe 
                style={{border: 0, width: '100%', height: '472px'}} 
                src="https://bandcamp.com/EmbeddedPlayer/album=0/size=large/bgcol=0d0d0d/linkcol=00ffff/transparent=true/" 
                seamless
                title="Melvin Records - Bandcamp Player"
              >
                <a href="https://melvinrecords.bandcamp.com/">
                  Melvin Records by Various Artists
                </a>
              </iframe>
            </div>

            <a 
              href="https://melvinrecords.bandcamp.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary group"
            >
              Visitar Bandcamp Completo
              <ExternalLink className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </a>
          </motion.div>
        </div>
      </section>
    </>
  )
}

export default Musica
